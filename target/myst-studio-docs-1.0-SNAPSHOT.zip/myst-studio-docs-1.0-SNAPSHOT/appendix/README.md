## {{ page.title }}

* [Artifact Type and Properties](artifact/README.md)  
